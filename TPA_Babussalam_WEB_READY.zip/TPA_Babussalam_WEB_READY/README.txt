TPA BABUSSALAM — WEB READY

File utama: index.html

Cara tercepat menjalankan:
1. Upload folder/file ini ke GitHub Codespaces.
2. Buka Terminal di folder tersebut.
3. Jalankan: python3 -m http.server 8080 --bind 0.0.0.0
4. Buka port 8080 pada Codespaces (Open in Browser).

Catatan: jangan gunakan preview attachment ChatGPT untuk menjalankan HTML.
